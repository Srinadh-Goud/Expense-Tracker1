#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structures
struct Registration {   //defining structure for registration
    char firstName[20];
    char lastName[20];
    char username[20];
    char email[50];
    char password[20];
};

struct Login {          //defining a structure for logging in
    char username[20];
    char password[20];
};

struct Expense {        //defining a structure to track expenses
    char category[50];
    float amount;
    char date[11]; // Format: YYYY-MM-DD
};

// Function prototypes
int validateDate(const char *date); // Prototype for validateDate function

void registration(struct Registration *reg);
void login(struct Login *log, struct Registration *reg, int *isLoggedIn);
void addExpense(struct Expense **expenses, int *count);
void displayExpensesByCategory(struct Expense *expenses, int count);
void generateMonthlySummary(struct Expense *expenses, int count);


// Functions
void registration(struct Registration *reg) {   //defining a function to register user details
    printf("\nRegistration:\nPlease enter the following details:\n");
    printf("First Name: ");
    scanf("%s", reg->firstName);
    printf("Last Name: ");
    scanf("%s", reg->lastName);
    printf("Username: ");
    scanf("%s", reg->username);
    printf("Email: ");
    scanf("%s", reg->email);
    printf("Password: ");
    scanf("%s", reg->password);

    printf("\nYou have successfully registered. Here are your details:\n");
    printf("Name: %s %s\nUsername: %s\nEmail: %s\n\n", reg->firstName, reg->lastName, reg->username, reg->email);
}

void login(struct Login *log, struct Registration *reg, int *isLoggedIn) {  //defining a function for logging in
    printf("\nLogin:\n");
    printf("Username: ");
    scanf("%s", log->username);
    printf("Password: ");
    scanf("%s", log->password);

    if (strcmp(log->username, reg->username) == 0 && strcmp(log->password, reg->password) == 0) {   //case of correct password
        printf("You have successfully logged in.\n\n");
        *isLoggedIn = 1;
    } else if (strcmp(log->username, reg->username) == 0) { //case of user forgetting password
        printf("Incorrect password.\nForgot password? (yes/no): ");
        char choice[5];
        scanf("%s", choice);
        if (strcmp(choice, "yes") == 0) {
            printf("Confirm email: ");
            char email[50];
            scanf("%s", email);
            if (strcmp(email, reg->email) == 0) {
                printf("Here is your password: %s\n\n", reg->password); //if email exists , the password will be retrieved and given
            } else {
                printf("No such email is associated with your account.\n"); //case of no valid email associated with the account
            }
        }
    } else {
        printf("Account not found. Please register first.\n\n");    //case of account not found
    }
}

void addExpense(struct Expense **expenses, int *count) {    //defining function to add expenses
    char choice;
    do {
        *expenses = realloc(*expenses, (*count + 1) * sizeof(struct Expense));
        if (*expenses == NULL) {
            printf("Memory allocation failed!\n");
            exit(1);
        }

        printf("\nCategories:\n");  //asking user to enter the expenses
        printf("1. Food\n2. Entertainment\n3. Bills\n4. Transport\n5. Education\n6. Loans\n7. Others\n");
        printf("Enter the number corresponding to the expense category: ");
        int categoryChoice;
        scanf("%d", &categoryChoice);
        switch (categoryChoice) {
            case 1: strcpy((*expenses)[*count].category, "Food"); break;
            case 2: strcpy((*expenses)[*count].category, "Entertainment"); break;
            case 3: strcpy((*expenses)[*count].category, "Bills"); break;
            case 4: strcpy((*expenses)[*count].category, "Transport"); break;
            case 5: strcpy((*expenses)[*count].category, "Education"); break;
            case 6: strcpy((*expenses)[*count].category, "Loans"); break;
            case 7: strcpy((*expenses)[*count].category, "Others"); break;
            default: printf("Invalid category choice!\n"); continue;
        }

        printf("Enter the expense amount: ");
        scanf("%f", &(*expenses)[*count].amount);

        do {
            printf("Enter date (YYYY-MM-DD): ");    //asking user to enter date of expense
            scanf("%s", (*expenses)[*count].date);
        } while (!validateDate((*expenses)[*count].date));

        (*count)++;
        printf("Do you want to add another expense? (y/n): ");  //asking user if they want to enter another expense
        scanf(" %c", &choice);
    } while (choice == 'y' || choice == 'Y');
}

int validateDate(const char *date) {    //function to check whether the date entered is valid
    if (strlen(date) != 10) return 0;
    if (date[4] != '-' || date[7] != '-') return 0;
    for (int i = 0; i < 10; i++) {
        if (i == 4 || i == 7) continue;
        if (date[i] < '0' || date[i] > '9') return 0;
    }
    return 1;
}

void displayExpensesByCategory(struct Expense *expenses, int count) {   //function to search the amount spent category-wise
    int categoryChoice;
    char category[50];
    int found = 0;

    printf("\nCategories:\n");
    printf("1. Food\n2. Entertainment\n3. Bills\n4. Transport\n5. Education\n6. Loans\n7. Others\n");
    printf("Enter the number corresponding to the expense category: ");
    scanf("%d", &categoryChoice);

    // Map the category number to the appropriate string
    switch (categoryChoice) {
        case 1: strcpy(category, "Food"); break;
        case 2: strcpy(category, "Entertainment"); break;
        case 3: strcpy(category, "Bills"); break;
        case 4: strcpy(category, "Transport"); break;
        case 5: strcpy(category, "Education"); break;
        case 6: strcpy(category, "Loans"); break;
        case 7: strcpy(category, "Others"); break;
        default: 
            printf("Invalid category choice!\n");
            return;
    }

    printf("\nExpenses in category '%s':\n", category);
    printf("----------------------------------\n");
    for (int i = 0; i < count; i++) {
        if (strcmp(expenses[i].category, category) == 0) {
            printf("Amount: %.2f, Date: %s\n", expenses[i].amount, expenses[i].date);
            found = 1;
        }
    }

    if (!found) {
        printf("No expenses found in this category.\n");
    }
}

void generateMonthlySummary(struct Expense *expenses, int count) {  //function to generate monthly summary
    char yearMonth[8];  
    printf("\nEnter the year and month (YYYY-MM): ");
    scanf("%s", yearMonth);

    printf("\nSummary for %s:\n", yearMonth);
    printf("----------------------------------\n");
    float total = 0.0;
    for (int i = 0; i < count; i++) {
        if (strncmp(expenses[i].date, yearMonth, 7) == 0) {
            printf("Category: %s, Amount: %.2f, Date: %s\n", expenses[i].category, expenses[i].amount, expenses[i].date);
            total += expenses[i].amount;
        }
    }
    printf("Total Expenses: %.2f\n", total);
}

// Main function
int main() {
    struct Registration reg;
    struct Login log;
    struct Expense *expenses = NULL;
    int expenseCount = 0;
    int isLoggedIn = 0;

    printf("\nWelcome to the Expense Tracker.\nDo you have an account? (1.yes/0.no): ");
    int ans;
    scanf("%d", &ans); 
    if (ans == 0) {
        registration(&reg);
    }

    login(&log, &reg, &isLoggedIn);

    if (isLoggedIn) {
        int choice;
        do {
            printf("\nExpense Tracker Menu:\n");
            printf("1. Add Expense\n");
            printf("2. Display Expenses by Category\n");
            printf("3. Generate Monthly Summary\n");
            printf("4. Exit\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch (choice) {
                case 1:
                    addExpense(&expenses, &expenseCount);
                    break;
                case 2:
                    displayExpensesByCategory(expenses, expenseCount);
                    break;
                case 3:
                    generateMonthlySummary(expenses, expenseCount);
                    break;
                case 4:
                    printf("Exiting the program. Goodbye!\n");
                    break;
                default:
                    printf("Invalid choice. Please try again.\n");
            }
        } while (choice != 4);

        free(expenses);
    }

    return 0;
}
